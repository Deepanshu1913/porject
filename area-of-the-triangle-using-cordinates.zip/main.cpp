/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <math.h>
using namespace std;

int
main ()
{
  int a, b, c, d, e, f;
  cout << "ENTER THE VALUE OF (a,b) , (c,d) , (e,f) : \n ";
  cin >> a >> b >> c >> d >> e >> f;

  // A, B, C are the side of triangle
  float A, B, C,s,area;
  A=sqrt(pow(d-b,2)+pow(c-a,2));
  cout<< "DISTANCE BETWEEN (a,b) , (c,d) is : \n " <<A;
  B=sqrt(pow(f-d,2)+pow(e-c,2));
  cout<< "\n DISTANCE BETWEEN (c,d) , (e,f) is : \n " <<B;
  C=sqrt(pow(f-b,2)+pow(e-a,2));
  cout<< "\n DISTANCE BETWEEN (a,b) , (e,f) is : \n " <<C <<" \n ";
  s= (A+B+C)/2;
  area = sqrt(s*(s-A)*(s-B)*(s-C));
  cout<<"AREA OF TRIANGLE :" <<area;
  return 0;
}
